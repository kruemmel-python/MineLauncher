package com.example.rpg.behavior;

public enum BehaviorStatus {
    SUCCESS,
    FAILURE,
    RUNNING
}
