package com.example.rpg.dungeon.layout;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.util.Vector;

public class Corridor {
    private final List<Vector> path = new ArrayList<>();

    public List<Vector> path() {
        return path;
    }
}
