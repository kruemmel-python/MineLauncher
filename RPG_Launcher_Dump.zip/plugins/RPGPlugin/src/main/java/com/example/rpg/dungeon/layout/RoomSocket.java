package com.example.rpg.dungeon.layout;

import org.bukkit.Location;

public record RoomSocket(String name, Location location) {
}
