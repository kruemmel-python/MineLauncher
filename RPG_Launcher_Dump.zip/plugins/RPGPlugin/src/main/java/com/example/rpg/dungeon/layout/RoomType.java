package com.example.rpg.dungeon.layout;

public enum RoomType {
    START,
    COMBAT,
    LOOT,
    ELITE,
    BOSS,
    EXIT,
    PUZZLE
}
