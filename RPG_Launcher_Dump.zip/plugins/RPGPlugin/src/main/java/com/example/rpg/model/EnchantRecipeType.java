package com.example.rpg.model;

public enum EnchantRecipeType {
    STAT_UPGRADE,
    AFFIX
}
