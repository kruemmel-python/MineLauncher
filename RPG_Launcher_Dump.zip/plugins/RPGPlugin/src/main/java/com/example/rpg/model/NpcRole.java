package com.example.rpg.model;

public enum NpcRole {
    QUESTGIVER,
    VENDOR,
    WEAPON_VENDOR,
    ARMOR_VENDOR,
    ITEM_VENDOR,
    RESOURCE_VENDOR,
    TRAINER,
    TELEPORTER,
    BANKER,
    FACTION_AGENT
}
