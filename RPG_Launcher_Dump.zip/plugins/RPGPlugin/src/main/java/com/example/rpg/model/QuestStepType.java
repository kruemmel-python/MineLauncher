package com.example.rpg.model;

public enum QuestStepType {
    KILL,
    COLLECT,
    TALK,
    EXPLORE,
    CRAFT,
    USE_ITEM,
    DEFEND,
    ESCORT
}
