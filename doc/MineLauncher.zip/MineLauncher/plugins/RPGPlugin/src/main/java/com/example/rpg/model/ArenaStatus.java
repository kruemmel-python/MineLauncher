package com.example.rpg.model;

public enum ArenaStatus {
    WAITING,
    FIGHTING,
    ENDING
}
