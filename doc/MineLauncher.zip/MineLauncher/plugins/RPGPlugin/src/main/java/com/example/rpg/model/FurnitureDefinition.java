package com.example.rpg.model;

public record FurnitureDefinition(String schematic, int offsetX, int offsetY, int offsetZ, int rotation) {
}
