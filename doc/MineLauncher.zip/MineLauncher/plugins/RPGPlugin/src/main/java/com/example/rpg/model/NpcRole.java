package com.example.rpg.model;

public enum NpcRole {
    QUESTGIVER,
    VENDOR,
    TRAINER,
    TELEPORTER,
    BANKER,
    FACTION_AGENT
}
