package com.example.rpg.model;

public enum Profession {
    GATHERING,
    CRAFTING
}
