package com.example.rpg.model;

public enum RPGStat {
    STRENGTH,
    DEXTERITY,
    CONSTITUTION,
    INTELLIGENCE,
    LUCK
}
