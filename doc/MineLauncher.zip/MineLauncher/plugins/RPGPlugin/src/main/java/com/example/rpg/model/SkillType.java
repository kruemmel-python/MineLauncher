package com.example.rpg.model;

public enum SkillType {
    ACTIVE,
    PASSIVE
}
