package com.example.rpg.permissions;

public enum PermissionDecision {
    ALLOW,
    DENY,
    INHERIT
}
