package com.example.rpg.schematic.nbt;

public interface NbtTag {
    byte typeId();
}
