package com.example.rpg.skill;

public enum SkillEffectType {
    HEAL,
    DAMAGE,
    PROJECTILE,
    POTION,
    SOUND,
    XP,
    PARTICLE,
    VELOCITY,
    AGGRO
}
