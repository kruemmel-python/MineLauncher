package com.example.rpg.model;

public enum GuildMemberRole {
    LEADER,
    OFFICER,
    MEMBER
}
