package com.example.rpg.model;

public enum SkillCategory {
    HEALING,
    MAGIC,
    ATTACK,
    DEFENSE,
    PROFESSION
}
